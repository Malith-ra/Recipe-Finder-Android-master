package com.saneth.recipes;

public class LoadMessages {


    String messageid;
    String messagenumber;
    String messagedetails;


    LoadMessages(String messageid, String messagenumber, String messagedetails){

         messageid =this.messageid;
        messagenumber = this.messagenumber;
        messagedetails = this.messagedetails;



    }

    LoadMessages(){


    }


}
