package com.saneth.recipes;

public class LoadBlockNumbers {


    String blockidid;
    String blockname;
    String blocknumber;


    LoadBlockNumbers(String blockidid,String blockname,String blocknumber){

        blockidid =this.blockidid;
        blockname = this.blockname;
        blocknumber = this.blocknumber;



    }

    LoadBlockNumbers(){


    }
}
