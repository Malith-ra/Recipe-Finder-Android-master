package com.saneth.recipes;

public class LoadBlockNumbersSearch {

    String blockidid;
    String blockname;
    String blocknumber;


    LoadBlockNumbersSearch(String blockidid,String blockname,String blocknumber){

        blockidid =this.blockidid;
        blockname = this.blockname;
        blocknumber = this.blocknumber;



    }

    LoadBlockNumbersSearch(){


    }



}
