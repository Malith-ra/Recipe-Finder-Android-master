package com.saneth.recipes;

import android.provider.BaseColumns;

public interface ConstantsMalith extends BaseColumns {
    public static final String TABLE_NAME = "products1" ;
    public static final String CARD_NAME = "name1" ;
    public static final String CARD_NUMBER = "weight1" ;
    public static final String CVC= "price1" ;
    public static final String EXPIRY_DATE = "description1" ;
    public static final String AVAILABILITY = "availability1" ;
}
